<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);

    // Validate form data
    if (empty($name) || empty($email) || empty($message)) {
        // If any field is empty, redirect back to the form with an error message
        header("Location: Contact.html?error=Please fill in all fields.");
        exit;
    }

    // Sanitize email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // If the email is not valid, redirect back to the form with an error message
        header("Location: Contact.html?error=Please enter a valid email address.");
        exit;
    }


    $to = "Onobuneromobor80@gmail.com";

    // Set the email subject
    $subject = "New Contact Form Submission from $name";

    // Build the email content
    $email_content = "Name: $name\n";
    $email_content = "Email: $email\n";
    $email_content .= "Message:\n$message\n";

    // Build the email headers
    $headers = "From: $name <$email>";

    // Send the email
    if (mail($to, $subject, $email_content, $headers)) {
        // Redirect to the form with a success message
        header("Location: Contact.html?success=Thank you! Your message has been sent.");
    } else {
        // If email sending fails, redirect back to the form with an error message
        header("Location: Contact.html?error=There was a problem sending your message. Please try again.");
    }
} else {
    // If the form is accessed directly, redirect to the contact form
    header("Location: Contact.html");
    exit;
}
